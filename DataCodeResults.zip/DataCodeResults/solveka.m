function [k2]=solveka(w,k1,n,m)
sm1=sum(w.*k1);
sm2=sm1-sum(w(1,n:m).*k1(1,n:m));
k2=k1;
k2(1,n:m)=k2(1,n:m)+0.5;
while sum(w(1,n:m).*k2(1,n:m))<1*sm2
    k2(1,n:m)=k2(1,n:m)+0.5;
end
end