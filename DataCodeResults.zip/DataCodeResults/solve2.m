for n=1:28
    b1(n)=max(a(:,n));
    b2(n)=min(a(:,n));
    for m=1:5
        c(m,n)=(a(m,n)-b2(n))/(b1(n)-b2(n));
    end
end