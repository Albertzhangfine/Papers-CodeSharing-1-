for n=1:19
    b(n)=sum(a(:,n));
    for m=1:9
        c(m,n)=a(m,n)/b(n);
    end
end